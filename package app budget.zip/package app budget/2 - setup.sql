-- ============================================================================
-- CAPFM CONSUMPTION MONITORING V2 - DEPLOY ALL (From Scratch)
-- ============================================================================
-- Version: 2.0
-- Date: 2026-02-04
-- Changements V2:
--   - Budgets avec dates de début/fin flexibles (au lieu d'année calendaire)
--   - Table ACCOUNT_CONSUMPTION pour stockage des données
--   - Vues hebdo/mensuel depuis début du budget avec axe temps continu
--   - Progression linéaire du budget (mois 1 = 1/N, mois 2 = 2/N, etc.)
--   - Split par compte pour entités multi-comptes
--   - Row Access Policies pour isolation multi-tenant
-- 
-- ⚠️ POINTS À MODIFIER AVANT EXÉCUTION :
--    - Ligne ~40 : PRODUCER_ACCOUNT_LOCATOR (locator du compte Producer)
--    - Ligne ~47 : CREDIT_PRICE_USD (prix du crédit en USD)
--    - Ligne ~95 : Les comptes dans ENTITY_ACCOUNTS (mapping entités/comptes)
-- ============================================================================

USE ROLE ACCOUNTADMIN;

-- ============================================================================
-- STEP 1: DATABASE & SCHEMA
-- ============================================================================
CREATE DATABASE IF NOT EXISTS CONSUMPTION_DB;
CREATE SCHEMA IF NOT EXISTS CONSUMPTION_DB.MONITORING;
USE DATABASE CONSUMPTION_DB;
USE SCHEMA MONITORING;

-- ============================================================================
-- STEP 2: APP_CONFIG (Configuration dynamique)
-- ============================================================================
CREATE TABLE IF NOT EXISTS APP_CONFIG (
    config_key VARCHAR(100) PRIMARY KEY,
    config_value VARCHAR(500),
    description VARCHAR(500),
    updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- ⚠️ MODIFIER 'AP17659' PAR LE LOCATOR DU PRODUCER CIBLE
MERGE INTO APP_CONFIG AS target
USING (SELECT 'PRODUCER_ACCOUNT_LOCATOR' AS config_key, 'TK14025' AS config_value) AS source
ON target.config_key = source.config_key
WHEN MATCHED THEN UPDATE SET config_value = source.config_value, updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (config_key, config_value, description) 
    VALUES (source.config_key, source.config_value, 'Account locator du compte Producer qui voit toutes les données');

-- ⚠️ MODIFIER '3.5' PAR LE PRIX DU CRÉDIT CIBLE
MERGE INTO APP_CONFIG AS target
USING (SELECT 'CREDIT_PRICE_USD' AS config_key, '3.5' AS config_value) AS source
ON target.config_key = source.config_key
WHEN MATCHED THEN UPDATE SET config_value = source.config_value, updated_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (config_key, config_value, description) 
    VALUES (source.config_key, source.config_value, 'Prix du crédit Snowflake en USD');

-- ============================================================================
-- STEP 3: TABLES DE BASE
-- ============================================================================

-- Table: Mapping entités <-> comptes Snowflake
CREATE TABLE IF NOT EXISTS ENTITY_ACCOUNTS (
    entity_id VARCHAR(50) NOT NULL,
    entity_name VARCHAR(200) NOT NULL,
    account_locator VARCHAR(20) NOT NULL,
    account_name VARCHAR(200),
    region VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (entity_id, account_locator)
);

-- Table V2: Budgets avec dates début/fin flexibles
-- Un seul budget actif par entité à la fois (UNIQUE sur entity_id)
-- ⚠️ DROP pour forcer migration V1 -> V2 (structure différente)
DROP TABLE IF EXISTS ENTITY_BUDGETS;
CREATE TABLE ENTITY_BUDGETS (
    budget_id NUMBER AUTOINCREMENT PRIMARY KEY,
    entity_id VARCHAR(50) NOT NULL UNIQUE,
    entity_name VARCHAR(200),
    budget_amount NUMBER(18,2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    notes VARCHAR(500),
    created_by VARCHAR(100) DEFAULT CURRENT_USER(),
    created_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    updated_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- Table: Historique de consommation
CREATE TABLE IF NOT EXISTS ACCOUNT_CONSUMPTION (
    consumption_id NUMBER AUTOINCREMENT PRIMARY KEY,
    account_locator VARCHAR(20) NOT NULL,
    account_name VARCHAR(200),
    usage_date DATE NOT NULL,
    service_type VARCHAR(100),
    credits_used NUMBER(18,6) NOT NULL,
    credits_used_compute NUMBER(18,6) DEFAULT 0,
    credits_used_cloud_services NUMBER(18,6) DEFAULT 0,
    credits_adjustment NUMBER(18,6) DEFAULT 0,
    loaded_at TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    UNIQUE (account_locator, usage_date, service_type)
);

-- ============================================================================
-- STEP 4: DONNÉES INITIALES (Entités)
-- ⚠️ MODIFIER SELON LES COMPTES DE VOTRE ORGANISATION
-- ============================================================================
MERGE INTO ENTITY_ACCOUNTS AS target
USING (
    SELECT column1 AS entity_id, column2 AS entity_name, column3 AS account_locator, column4 AS account_name, column5 AS region
    FROM VALUES
        ('AGOS', 'AGOS', 'OS15260', 'AGOS1', 'AWS_EU_CENTRAL_1'),
        ('AGOS', 'AGOS', 'PG43146', 'AGOS2', 'AWS_EU_CENTRAL_1'),
        ('SOFINCO_ES', 'Sofinco Espagne', 'GQ93393', 'ESPAGNE', 'AWS_EU_CENTRAL_1'),
        ('ORGADMIN', 'CAPFM Central (Producer)', 'AP17659', 'TX56845', 'AWS_EU_CENTRAL_1'),
        ('creditbom', 'CreditBom', 'CL86935', 'creditbom', 'AWS_EU_CENTRAL_1')
        
) AS source
ON target.entity_id = source.entity_id AND target.account_locator = source.account_locator
WHEN NOT MATCHED THEN INSERT (entity_id, entity_name, account_locator, account_name, region)
    VALUES (source.entity_id, source.entity_name, source.account_locator, source.account_name, source.region);

-- ============================================================================
-- STEP 4b: TABLE LOOKUP POUR LES RAPs (évite référence circulaire)
-- ⚠️ IMPORTANT: Mettre à jour cette table à chaque ajout de compte
-- ============================================================================
CREATE OR REPLACE TABLE ENTITY_ACCOUNTS_LOOKUP AS 
SELECT entity_id, account_locator FROM ENTITY_ACCOUNTS;

-- ============================================================================
-- STEP 5: ROW ACCESS POLICIES (Multi-comptes par entité)
-- ============================================================================

-- RAP pour ACCOUNT_CONSUMPTION
CREATE OR REPLACE ROW ACCESS POLICY RAP_ACCOUNT_CONSUMPTION
AS (account_locator VARCHAR) RETURNS BOOLEAN ->
    CURRENT_ACCOUNT() = (SELECT config_value FROM CONSUMPTION_DB.MONITORING.APP_CONFIG WHERE config_key = 'PRODUCER_ACCOUNT_LOCATOR')
    OR
    account_locator IN (
        SELECT ea2.account_locator 
        FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP ea2 
        WHERE ea2.entity_id IN (
            SELECT ea1.entity_id 
            FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP ea1 
            WHERE ea1.account_locator = CURRENT_ACCOUNT()
        )
    );

-- RAP pour ENTITY_ACCOUNTS
CREATE OR REPLACE ROW ACCESS POLICY RAP_ENTITY_ACCOUNTS
AS (account_locator VARCHAR) RETURNS BOOLEAN ->
    CURRENT_ACCOUNT() = (SELECT config_value FROM CONSUMPTION_DB.MONITORING.APP_CONFIG WHERE config_key = 'PRODUCER_ACCOUNT_LOCATOR')
    OR
    account_locator IN (
        SELECT ea2.account_locator 
        FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP ea2 
        WHERE ea2.entity_id IN (
            SELECT ea1.entity_id 
            FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP ea1 
            WHERE ea1.account_locator = CURRENT_ACCOUNT()
        )
    );

-- RAP pour ENTITY_BUDGETS
CREATE OR REPLACE ROW ACCESS POLICY RAP_ENTITY_BUDGETS
AS (entity_id VARCHAR) RETURNS BOOLEAN ->
    CURRENT_ACCOUNT() = (SELECT config_value FROM CONSUMPTION_DB.MONITORING.APP_CONFIG WHERE config_key = 'PRODUCER_ACCOUNT_LOCATOR')
    OR
    entity_id IN (
        SELECT ea.entity_id 
        FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP ea 
        WHERE ea.account_locator = CURRENT_ACCOUNT()
    );

-- Appliquer les RAPs (ignorer erreur si déjà appliquées)
ALTER TABLE ACCOUNT_CONSUMPTION ADD ROW ACCESS POLICY RAP_ACCOUNT_CONSUMPTION ON (account_locator);
ALTER TABLE ENTITY_ACCOUNTS ADD ROW ACCESS POLICY RAP_ENTITY_ACCOUNTS ON (account_locator);
ALTER TABLE ENTITY_BUDGETS ADD ROW ACCESS POLICY RAP_ENTITY_BUDGETS ON (entity_id);

-- ============================================================================
-- STEP 6: SECURE VIEWS V2
-- ============================================================================

-- Vue: Consommation journalière (pour admin)
CREATE OR REPLACE SECURE VIEW V_DAILY_CONSUMPTION AS
SELECT 
    c.usage_date, c.account_locator, c.account_name,
    e.entity_id, e.entity_name, c.service_type,
    c.credits_used, c.credits_used_compute, c.credits_used_cloud_services, c.credits_adjustment,
    c.credits_used * (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS cost_usd
FROM ACCOUNT_CONSUMPTION c
LEFT JOIN ENTITY_ACCOUNTS e ON c.account_locator = e.account_locator;

-- Vue V2: Consommation hebdomadaire depuis début du budget
CREATE OR REPLACE SECURE VIEW V_WEEKLY_CONSUMPTION AS
WITH budget_dates AS (
    SELECT entity_id, start_date AS budget_start, end_date AS budget_end
    FROM ENTITY_BUDGETS
),
all_weeks AS (
    SELECT 
        bd.entity_id,
        bd.budget_start,
        DATE_TRUNC('week', DATEADD(day, seq4() * 7, bd.budget_start)) AS week_start
    FROM budget_dates bd,
    TABLE(GENERATOR(ROWCOUNT => 104))
    WHERE DATE_TRUNC('week', DATEADD(day, seq4() * 7, bd.budget_start)) <= LEAST(CURRENT_DATE(), bd.budget_end)
),
all_accounts AS (
    SELECT DISTINCT entity_id, entity_name, account_locator, account_name
    FROM ENTITY_ACCOUNTS WHERE is_active = TRUE
),
week_account_grid AS (
    SELECT DISTINCT w.week_start, a.entity_id, a.entity_name, a.account_locator, a.account_name
    FROM all_weeks w
    JOIN all_accounts a ON w.entity_id = a.entity_id
),
consumption_by_week AS (
    SELECT 
        DATE_TRUNC('week', c.usage_date) AS week_start,
        c.account_locator,
        SUM(c.credits_used) AS credits_used,
        SUM(c.credits_used_compute) AS credits_compute,
        SUM(c.credits_used_cloud_services) AS credits_cloud
    FROM ACCOUNT_CONSUMPTION c
    GROUP BY 1, 2
)
SELECT 
    g.week_start,
    DATEADD(day, 6, g.week_start) AS week_end,
    YEAROFWEEKISO(g.week_start) AS iso_year,
    WEEKISO(g.week_start) AS iso_week,
    g.entity_id,
    g.entity_name,
    g.account_locator,
    g.account_name,
    COALESCE(c.credits_used, 0) AS credits_used,
    COALESCE(c.credits_compute, 0) AS credits_compute,
    COALESCE(c.credits_cloud, 0) AS credits_cloud,
    COALESCE(c.credits_used, 0) * (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS cost_usd
FROM week_account_grid g
LEFT JOIN consumption_by_week c ON g.week_start = c.week_start AND g.account_locator = c.account_locator
ORDER BY g.week_start, g.entity_id, g.account_locator;

-- Vue V2: Consommation mensuelle depuis début du budget
CREATE OR REPLACE SECURE VIEW V_MONTHLY_CONSUMPTION AS
WITH budget_dates AS (
    SELECT entity_id, start_date AS budget_start, end_date AS budget_end
    FROM ENTITY_BUDGETS
),
all_months AS (
    SELECT 
        bd.entity_id,
        DATEADD(month, seq4(), DATE_TRUNC('month', bd.budget_start)) AS month_start
    FROM budget_dates bd,
    TABLE(GENERATOR(ROWCOUNT => 24))
    WHERE DATEADD(month, seq4(), DATE_TRUNC('month', bd.budget_start)) <= LEAST(CURRENT_DATE(), bd.budget_end)
),
all_accounts AS (
    SELECT DISTINCT entity_id, entity_name, account_locator, account_name
    FROM ENTITY_ACCOUNTS WHERE is_active = TRUE
),
month_account_grid AS (
    SELECT DISTINCT m.month_start, a.entity_id, a.entity_name, a.account_locator, a.account_name
    FROM all_months m
    JOIN all_accounts a ON m.entity_id = a.entity_id
),
consumption_by_month AS (
    SELECT 
        DATE_TRUNC('month', c.usage_date) AS month_start,
        c.account_locator,
        SUM(c.credits_used) AS credits_used,
        SUM(c.credits_used_compute) AS credits_compute,
        SUM(c.credits_used_cloud_services) AS credits_cloud
    FROM ACCOUNT_CONSUMPTION c
    GROUP BY 1, 2
)
SELECT 
    g.month_start,
    LAST_DAY(g.month_start) AS month_end,
    YEAR(g.month_start) AS year,
    MONTH(g.month_start) AS month,
    g.entity_id,
    g.entity_name,
    g.account_locator,
    g.account_name,
    COALESCE(c.credits_used, 0) AS credits_used,
    COALESCE(c.credits_compute, 0) AS credits_compute,
    COALESCE(c.credits_cloud, 0) AS credits_cloud,
    COALESCE(c.credits_used, 0) * (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS cost_usd
FROM month_account_grid g
LEFT JOIN consumption_by_month c ON g.month_start = c.month_start AND g.account_locator = c.account_locator
ORDER BY g.month_start, g.entity_id, g.account_locator;

-- Vue V2: Budget vs Consommation réelle
CREATE OR REPLACE SECURE VIEW V_BUDGET_VS_ACTUAL AS
WITH budget_info AS (
    SELECT 
        b.entity_id,
        b.entity_name,
        b.budget_amount AS budget_credits,
        b.start_date,
        b.end_date,
        DATEDIFF(day, b.start_date, b.end_date) + 1 AS budget_days,
        DATEDIFF(day, b.start_date, LEAST(CURRENT_DATE(), b.end_date)) + 1 AS elapsed_days,
        (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS credit_price
    FROM ENTITY_BUDGETS b
    WHERE CURRENT_DATE() BETWEEN b.start_date AND b.end_date
),
actual_consumption AS (
    SELECT 
        e.entity_id,
        SUM(c.credits_used) AS total_credits,
        SUM(c.credits_used) * (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS total_cost_usd
    FROM ACCOUNT_CONSUMPTION c
    JOIN ENTITY_ACCOUNTS e ON c.account_locator = e.account_locator
    JOIN ENTITY_BUDGETS b ON e.entity_id = b.entity_id
    WHERE c.usage_date BETWEEN b.start_date AND CURRENT_DATE()
    GROUP BY e.entity_id
)
SELECT 
    bi.entity_id,
    bi.entity_name,
    bi.budget_credits,
    bi.budget_credits * bi.credit_price AS budget_amount_usd,
    bi.start_date,
    bi.end_date,
    bi.budget_days,
    bi.elapsed_days,
    bi.credit_price AS credit_price_usd,
    COALESCE(ac.total_credits, 0) AS actual_credits,
    COALESCE(ac.total_cost_usd, 0) AS actual_cost_usd,
    bi.budget_credits - COALESCE(ac.total_credits, 0) AS remaining_credits,
    (bi.budget_credits * bi.credit_price) - COALESCE(ac.total_cost_usd, 0) AS remaining_amount_usd,
    CASE WHEN bi.budget_credits > 0 
         THEN ROUND((COALESCE(ac.total_credits, 0) / bi.budget_credits) * 100, 2) 
         ELSE 0 END AS budget_consumption_pct,
    ROUND((bi.budget_credits / bi.budget_days) * bi.elapsed_days, 2) AS expected_credits_to_date,
    CASE 
        WHEN COALESCE(ac.total_credits, 0) > bi.budget_credits THEN 'OVER_BUDGET'
        WHEN COALESCE(ac.total_credits, 0) > (bi.budget_credits / bi.budget_days) * bi.elapsed_days * 1.1 THEN 'WARNING'
        WHEN COALESCE(ac.total_credits, 0) > (bi.budget_credits / bi.budget_days) * bi.elapsed_days * 0.9 THEN 'ON_TRACK'
        ELSE 'UNDER_BUDGET'
    END AS budget_status
FROM budget_info bi
LEFT JOIN actual_consumption ac ON bi.entity_id = ac.entity_id;

-- Vue V2: Cumul mensuel pour graphique comparatif budget vs consommation
-- Progression linéaire: mois 1 = 1/N, mois 2 = 2/N, etc. (N = nombre de mois du budget)
-- Commence à la date de début du budget
CREATE OR REPLACE SECURE VIEW V_MONTHLY_CUMULATIVE AS
WITH budget_info AS (
    SELECT 
        b.entity_id,
        b.entity_name,
        b.budget_amount,
        b.start_date,
        b.end_date,
        DATE_TRUNC('month', b.start_date) AS budget_month_start,
        DATEDIFF(month, DATE_TRUNC('month', b.start_date), DATE_TRUNC('month', b.end_date)) + 1 AS budget_months
    FROM ENTITY_BUDGETS b
),
all_months AS (
    SELECT 
        bi.entity_id,
        bi.entity_name,
        bi.budget_amount,
        bi.start_date AS budget_start,
        bi.end_date AS budget_end,
        bi.budget_months,
        DATEADD(month, seq4(), bi.budget_month_start) AS month_start,
        seq4() + 1 AS month_num
    FROM budget_info bi,
    TABLE(GENERATOR(ROWCOUNT => 24))
    WHERE DATEADD(month, seq4(), bi.budget_month_start) <= LEAST(CURRENT_DATE(), bi.end_date)
),
monthly_consumption AS (
    SELECT 
        e.entity_id,
        DATE_TRUNC('month', c.usage_date) AS month_start,
        SUM(c.credits_used) AS monthly_credits
    FROM ACCOUNT_CONSUMPTION c
    JOIN ENTITY_ACCOUNTS e ON c.account_locator = e.account_locator
    JOIN ENTITY_BUDGETS b ON e.entity_id = b.entity_id
    WHERE c.usage_date >= b.start_date
    GROUP BY 1, 2
)
SELECT 
    am.entity_id,
    am.entity_name,
    am.month_start,
    LAST_DAY(am.month_start) AS month_end,
    COALESCE(mc.monthly_credits, 0) AS monthly_credits,
    SUM(COALESCE(mc.monthly_credits, 0)) OVER (PARTITION BY am.entity_id ORDER BY am.month_start) AS cumul_credits,
    am.budget_amount,
    am.budget_start,
    am.budget_end,
    ROUND((am.budget_amount / am.budget_months) * am.month_num, 2) AS cumul_budget_expected,
    (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS credit_price_usd
FROM all_months am
LEFT JOIN monthly_consumption mc ON am.entity_id = mc.entity_id AND am.month_start = mc.month_start
ORDER BY am.entity_id, am.month_start;

-- Vue: Résumé organisation (admin)
CREATE OR REPLACE SECURE VIEW V_ORG_SUMMARY AS
SELECT 
    DATE_TRUNC('month', c.usage_date) AS month,
    COUNT(DISTINCT c.account_locator) AS active_accounts,
    COUNT(DISTINCT e.entity_id) AS active_entities,
    SUM(c.credits_used) AS total_credits,
    SUM(c.credits_used) * (SELECT config_value::FLOAT FROM APP_CONFIG WHERE config_key = 'CREDIT_PRICE_USD') AS total_cost_usd
FROM ACCOUNT_CONSUMPTION c
LEFT JOIN ENTITY_ACCOUNTS e ON c.account_locator = e.account_locator
WHERE c.usage_date >= DATEADD(month, -6, DATE_TRUNC('month', CURRENT_DATE()))
GROUP BY 1 ORDER BY 1 DESC;

-- ============================================================================
-- STEP 7: TASK - Chargement incrémental quotidien
-- ============================================================================

-- Chargement initial historique complet (à exécuter une seule fois)
INSERT INTO ACCOUNT_CONSUMPTION (account_locator, account_name, usage_date, service_type, credits_used, credits_used_compute, credits_used_cloud_services, credits_adjustment)
SELECT 
    m.account_locator, a.account_name, m.usage_date, m.service_type,
    m.credits_used, m.credits_used_compute, m.credits_used_cloud_services,
    m.credits_adjustment_cloud_services
FROM SNOWFLAKE.ORGANIZATION_USAGE.METERING_DAILY_HISTORY m
JOIN SNOWFLAKE.ORGANIZATION_USAGE.ACCOUNTS a ON m.account_locator = a.account_locator
WHERE NOT EXISTS (
    SELECT 1 FROM ACCOUNT_CONSUMPTION h 
    WHERE h.account_locator = m.account_locator 
    AND h.usage_date = m.usage_date 
    AND h.service_type = m.service_type
);

-- Task quotidienne pour charger les nouvelles données
CREATE OR REPLACE TASK TASK_LOAD_DAILY_CONSUMPTION
    WAREHOUSE = COMPUTE_WH
    SCHEDULE = 'USING CRON 0 6 * * * UTC'
AS
MERGE INTO ACCOUNT_CONSUMPTION tgt
USING (
    SELECT 
        m.account_locator, a.account_name, m.usage_date, m.service_type,
        m.credits_used, m.credits_used_compute, m.credits_used_cloud_services,
        m.credits_adjustment_cloud_services as credits_adjustment
    FROM SNOWFLAKE.ORGANIZATION_USAGE.METERING_DAILY_HISTORY m
    JOIN SNOWFLAKE.ORGANIZATION_USAGE.ACCOUNTS a ON m.account_locator = a.account_locator
    WHERE m.usage_date >= DATEADD(day, -7, CURRENT_DATE())
) src
ON tgt.account_locator = src.account_locator AND tgt.usage_date = src.usage_date AND tgt.service_type = src.service_type
WHEN MATCHED THEN UPDATE SET
    credits_used = src.credits_used, credits_used_compute = src.credits_used_compute,
    credits_used_cloud_services = src.credits_used_cloud_services, credits_adjustment = src.credits_adjustment,
    loaded_at = CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT (account_locator, account_name, usage_date, service_type, credits_used, credits_used_compute, credits_used_cloud_services, credits_adjustment)
    VALUES (src.account_locator, src.account_name, src.usage_date, src.service_type, src.credits_used, src.credits_used_compute, src.credits_used_cloud_services, src.credits_adjustment);

GRANT EXECUTE TASK ON ACCOUNT TO ROLE ACCOUNTADMIN;
ALTER TASK TASK_LOAD_DAILY_CONSUMPTION RESUME;

-- ============================================================================
-- STEP 8: APPLICATION PACKAGE
-- ============================================================================
DROP APPLICATION IF EXISTS CAPFM_BUDGET_APPLICATION;
DROP APPLICATION PACKAGE IF EXISTS CAPFM_CONSUMPTION_MONITOR_PKG;




CREATE APPLICATION PACKAGE IF NOT EXISTS CAPFM_CONSUMPTION_MONITOR_PKG
    COMMENT = 'CAPFM Consumption Monitoring Native App V1';

CREATE SCHEMA IF NOT EXISTS CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT;

CREATE OR REPLACE STAGE CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE
    DIRECTORY = (ENABLE = TRUE)
    ENCRYPTION = (TYPE = 'SNOWFLAKE_SSE');

-- Accès référentiel à CONSUMPTION_DB
GRANT REFERENCE_USAGE ON DATABASE CONSUMPTION_DB
    TO SHARE IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;

-- Schema pour les données partagées
CREATE SCHEMA IF NOT EXISTS CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA;

-- Vues V2 dans le package
CREATE OR REPLACE VIEW CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA.V_WEEKLY_CONSUMPTION AS SELECT * FROM CONSUMPTION_DB.MONITORING.V_WEEKLY_CONSUMPTION;
CREATE OR REPLACE VIEW CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA.V_MONTHLY_CONSUMPTION AS SELECT * FROM CONSUMPTION_DB.MONITORING.V_MONTHLY_CONSUMPTION;
CREATE OR REPLACE VIEW CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA.V_BUDGET_VS_ACTUAL AS SELECT * FROM CONSUMPTION_DB.MONITORING.V_BUDGET_VS_ACTUAL;
CREATE OR REPLACE VIEW CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA.V_MONTHLY_CUMULATIVE AS SELECT * FROM CONSUMPTION_DB.MONITORING.V_MONTHLY_CUMULATIVE;

-- Partager avec l'app package
GRANT USAGE ON SCHEMA CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA TO SHARE IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
GRANT SELECT ON ALL VIEWS IN SCHEMA CAPFM_CONSUMPTION_MONITOR_PKG.SHARED_DATA TO SHARE IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;

-- ============================================================================
-- STEP 9: UPLOAD DES FICHIERS (à faire manuellement via snow CLI)
-- ============================================================================
-- snow stage copy manifest.yml @CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE --overwrite -c <connection>
-- snow stage copy setup_script.sql @CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE --overwrite -c <connection>
-- snow stage copy README.md @CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE --overwrite -c <connection>
-- snow stage copy streamlit/ @CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE/streamlit --overwrite -c <connection>

-- ============================================================================
-- STEP 10: VERSION ET RELEASE DIRECTIVE
-- ============================================================================
-- À exécuter APRÈS avoir uploadé les fichiers sur le stage

-- Enregistrer la version V1
ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
   REGISTER VERSION V1
   USING '@CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE';

-- Ajouter la version au release channel DEFAULT
 ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
   MODIFY RELEASE CHANNEL DEFAULT
   ADD VERSION V1;

-- Définir le release directive par défaut
 ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
   MODIFY RELEASE CHANNEL DEFAULT
   SET DEFAULT RELEASE DIRECTIVE
   VERSION = V1
   PATCH = 0;

-- ============================================================================
-- STEP 11: VERIFICATION (exécuter une par une)
-- ============================================================================
SELECT * FROM CONSUMPTION_DB.MONITORING.APP_CONFIG;
 SELECT COUNT(*) AS nb_rows FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS;
 SELECT COUNT(*) AS nb_rows FROM CONSUMPTION_DB.MONITORING.ACCOUNT_CONSUMPTION;
 SELECT * FROM V_BUDGET_VS_ACTUAL;
 SELECT * FROM V_WEEKLY_CONSUMPTION LIMIT 20;
 SELECT * FROM V_MONTHLY_CONSUMPTION LIMIT 20;
 SELECT * FROM V_MONTHLY_CUMULATIVE;
 SHOW TASKS IN SCHEMA CONSUMPTION_DB.MONITORING;

-- ============================================================================
-- ⚠️ MAINTENANCE: Quand vous ajoutez un nouveau compte, exécutez:
-- ============================================================================
-- INSERT INTO CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS 
-- (entity_id, entity_name, account_locator, account_name, region)
-- VALUES ('NOM_ENTITE', 'Nom Entite', 'NOUVEAU_LOCATOR', 'NOM_COMPTE', 'AWS_EU_CENTRAL_1');
--
-- CREATE OR REPLACE TABLE CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP AS 
-- SELECT entity_id, account_locator FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS;
