/*
================================================================================
GUIDE RELEASE - Déployer une NOUVELLE VERSION d'une Native App
================================================================================
Une nouvelle VERSION nécessite une action MANUELLE du consumer pour upgrader.
Utiliser pour : nouvelle fonctionnalité, changement majeur, breaking change.

⚠️  VALEURS À MODIFIER selon votre contexte:
    - NOM_DU_PACKAGE      : nom de votre application package
    - CHEMIN_DU_STAGE     : chemin vers vos fichiers source
    - NOUVELLE_VERSION    : V1, V2, V3, V4... (nouvelle version à créer)
    - LABEL               : texte affiché aux consumers (ex: "Version 4.0")
    - COMMENT             : description des changements
================================================================================
*/

-- ============================================================================
-- ÉTAPE 1: Vérifier les versions existantes
-- ============================================================================
-- 📝 MODIFIER: Remplacer par le nom de votre package
SHOW VERSIONS IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                   👆 NOM_DU_PACKAGE

-- ============================================================================
-- ÉTAPE 2: Uploader vos fichiers modifiés sur le stage
-- ============================================================================
-- Faites vos modifications localement puis uploadez via PUT ou snow CLI
-- N'oubliez pas de mettre à jour le manifest.yml avec la nouvelle version!
--
-- Exemple manifest.yml:
-- version:
--   name: V4              <-- NOUVELLE_VERSION
--   label: "Version 4.0"  <-- LABEL
--   comment: "Description des changements"

-- ============================================================================
-- ÉTAPE 3: Créer la nouvelle version
-- ============================================================================
-- 📝 MODIFIER: 
--    - NOM_DU_PACKAGE    : votre application package
--    - NOUVELLE_VERSION  : nom de la version (ex: V4)
--    - LABEL             : texte affiché (ex: "Version 4.0 - Nouvelles fonctionnalités")
--    - COMMENT           : description détaillée des changements
--    - CHEMIN_DU_STAGE   : chemin complet vers vos fichiers source

ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
--                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                        👆 NOM_DU_PACKAGE
    ADD VERSION V4
--              ^^
--              👆 NOUVELLE_VERSION (doit être unique, ex: V4, V5...)
    LABEL = 'Version 4.0 - Nouvelles fonctionnalités'
--          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--          👆 LABEL (texte visible par les consumers)
    COMMENT = 'Ajout de fonctionnalité X, amélioration Y'
--            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--            👆 COMMENT (description des changements)
    USING '@CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE/app_code';
--        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--        👆 CHEMIN_DU_STAGE (chemin complet avec @)

-- ============================================================================
-- ÉTAPE 4: Vérifier que la version est créée
-- ============================================================================
SHOW VERSIONS IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                   👆 NOM_DU_PACKAGE

-- Vous devriez voir votre nouvelle version (V4 patch 0)

-- ============================================================================
-- ÉTAPE 5: ⚠️ OBLIGATOIRE - Activer la version pour les consumers
-- ============================================================================
-- SANS CETTE ÉTAPE, les consumers NE VERRONT PAS la nouvelle version!
--
-- 📝 MODIFIER:
--    - NOM_DU_PACKAGE    : votre application package
--    - NOUVELLE_VERSION  : la version créée à l'étape 3

ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
--                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                        👆 NOM_DU_PACKAGE
    MODIFY RELEASE CHANNEL DEFAULT
    SET DEFAULT RELEASE DIRECTIVE
    VERSION = V4
--            ^^
--            👆 NOUVELLE_VERSION (même qu'à l'étape 3)
    PATCH = 0;
--          ^
--          👆 Toujours 0 pour une nouvelle version

-- ============================================================================
-- ÉTAPE 6: Vérifier que tout est correct
-- ============================================================================
SHOW RELEASE DIRECTIVES IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                             👆 NOM_DU_PACKAGE

-- Résultat attendu: VERSION = V4, PATCH = 0

-- ============================================================================
-- ⚠️ DIFFÉRENCE IMPORTANTE AVEC UN PATCH
-- ============================================================================
-- 
-- PATCH  : S'applique AUTOMATIQUEMENT aux consumers existants
-- VERSION: Nécessite une action MANUELLE du consumer:
--
--          ALTER APPLICATION <NOM_APP_CHEZ_CONSUMER> UPGRADE;
--
-- Le consumer verra un message "Upgrade available" dans Snowsight
-- et devra choisir de faire la mise à jour.
--
-- ============================================================================
-- CÔTÉ CONSUMER: Upgrader vers la nouvelle version
-- ============================================================================
-- Le consumer doit exécuter:
--
--     ALTER APPLICATION CAPFM UPGRADE;
--                       ^^^^^
--                       👆 Nom de l'app installée chez le consumer
--
-- Ou cliquer sur "Upgrade" dans l'interface Snowsight