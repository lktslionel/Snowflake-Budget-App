/*
================================================================================
GUIDE PATCHING - Déployer une correction sur une Native App
================================================================================
Un PATCH s'applique AUTOMATIQUEMENT aux installations existantes.
Utiliser pour : bugfix, correction texte, amélioration mineure.

⚠️  VALEURS À MODIFIER selon votre contexte:
    - NOM_DU_PACKAGE      : nom de votre application package
    - CHEMIN_DU_STAGE     : chemin vers vos fichiers source
    - VERSION             : V1, V2, V3... (version cible)
    - PATCH               : numéro du patch créé (voir étape 4)
================================================================================
*/

-- ============================================================================
-- ÉTAPE 1: Vérifier les versions et patches existants
-- ============================================================================
-- 📝 MODIFIER: Remplacer par le nom de votre package
SHOW VERSIONS IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                   👆 NOM_DU_PACKAGE

-- ============================================================================
-- ÉTAPE 2: Uploader vos fichiers modifiés sur le stage
-- ============================================================================
-- Faites vos modifications localement puis uploadez via PUT ou snow CLI
-- (Cette étape se fait AVANT de créer le patch)

-- ============================================================================
-- ÉTAPE 3: Créer le patch
-- ============================================================================
-- 📝 MODIFIER: 
--    - NOM_DU_PACKAGE  : votre application package
--    - VERSION         : la version sur laquelle ajouter le patch (ex: V1, V2, V3)
--    - CHEMIN_DU_STAGE : chemin complet vers vos fichiers source

ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
--                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                        👆 NOM_DU_PACKAGE
    ADD PATCH FOR VERSION V3
--                        ^^
--                        👆 VERSION (ex: V1, V2, V3...)
    USING '@CAPFM_CONSUMPTION_MONITOR_PKG.STAGE_CONTENT.APP_CODE/app_code';
--        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--        👆 CHEMIN_DU_STAGE (chemin complet avec @)

-- ============================================================================
-- ÉTAPE 4: Noter le numéro de patch créé
-- ============================================================================
-- Cette commande affiche tous les patches. Notez le DERNIER numéro créé.
SHOW VERSIONS IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                   👆 NOM_DU_PACKAGE

-- Exemple de résultat:
-- | version | patch | ...
-- | V3      | 0     | ...
-- | V3      | 1     | ...
-- | V3      | 2     | ...  <-- Si c'est le dernier, PATCH = 2

-- ============================================================================
-- ÉTAPE 5: ⚠️ OBLIGATOIRE - Activer le patch pour les consumers
-- ============================================================================
-- SANS CETTE ÉTAPE, les consumers NE RECEVRONT PAS le nouveau patch!
--
-- 📝 MODIFIER:
--    - NOM_DU_PACKAGE : votre application package
--    - VERSION        : même version qu'à l'étape 3
--    - PATCH          : le numéro noté à l'étape 4

ALTER APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG
--                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                        👆 NOM_DU_PACKAGE
    MODIFY RELEASE CHANNEL DEFAULT
    SET DEFAULT RELEASE DIRECTIVE
    VERSION = V3
--            ^^
--            👆 VERSION (même qu'à l'étape 3)
    PATCH = 10;
--          ^^
--          👆 PATCH (numéro noté à l'étape 4)

-- ============================================================================
-- ÉTAPE 6: Vérifier que tout est correct
-- ============================================================================
-- Cette commande montre la version/patch actuellement distribués aux consumers
SHOW RELEASE DIRECTIVES IN APPLICATION PACKAGE CAPFM_CONSUMPTION_MONITOR_PKG;
--                                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
--                                             👆 NOM_DU_PACKAGE

-- Résultat attendu: VERSION = V3, PATCH = 10 (vos valeurs)

-- ============================================================================
-- CÔTÉ CONSUMER: Le patch sera appliqué automatiquement
-- ============================================================================
-- Option 1: Attendre quelques minutes (propagation automatique)
-- Option 2: Forcer la mise à jour immédiate:
--           ALTER APPLICATION <NOM_APP_CHEZ_CONSUMER> UPGRADE;

