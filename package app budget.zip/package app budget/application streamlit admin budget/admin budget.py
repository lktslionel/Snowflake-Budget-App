import streamlit as st
import pandas as pd
from snowflake.snowpark.context import get_active_session
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date

st.set_page_config(
    page_title="CAPFM Admin - Budget Management V3",
    page_icon="⚙️",
    layout="wide"
)

CAPFM_COLORS = {
    "vert_fonce": "#006A4E",
    "vert_clair": "#78BE20",
    "blanc": "#FFFFFF",
    "gris": "#F5F5F5"
}

st.markdown(f"""
<style>
    .stApp {{ background-color: {CAPFM_COLORS["gris"]}; }}
    .admin-header {{
        background: linear-gradient(90deg, {CAPFM_COLORS["vert_fonce"]} 0%, #004d38 100%);
        padding: 20px; border-radius: 10px; margin-bottom: 20px;
    }}
    .admin-header h1 {{ color: {CAPFM_COLORS["blanc"]}; margin: 0; }}
    .entity-card {{
        background: {CAPFM_COLORS["blanc"]}; padding: 15px; border-radius: 8px;
        border-left: 4px solid {CAPFM_COLORS["vert_clair"]}; margin: 10px 0;
    }}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="admin-header">
    <h1>⚙️ CAPFM Admin - Gestion des Budgets V3</h1>
</div>
""", unsafe_allow_html=True)

session = get_active_session()

@st.cache_data(ttl=60)
def get_entities():
    return session.sql("SELECT DISTINCT entity_id, entity_name FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS WHERE entity_id != 'ORGADMIN' ORDER BY entity_name").to_pandas()

@st.cache_data(ttl=60)
def get_budgets():
    return session.sql("""
        SELECT budget_id, entity_id, entity_name, budget_amount, start_date, end_date, notes, created_at
        FROM CONSUMPTION_DB.MONITORING.ENTITY_BUDGETS 
        ORDER BY start_date DESC
    """).to_pandas()

@st.cache_data(ttl=60)
def get_org_consumption():
    return session.sql("SELECT * FROM CONSUMPTION_DB.MONITORING.V_ORG_SUMMARY ORDER BY month DESC").to_pandas()

@st.cache_data(ttl=60)
def get_all_consumption():
    return session.sql("""
        SELECT usage_date, entity_name, account_locator, account_name, 
               SUM(credits_used) as credits, SUM(cost_usd) as cost_usd
        FROM CONSUMPTION_DB.MONITORING.V_DAILY_CONSUMPTION
        GROUP BY 1,2,3,4
        ORDER BY usage_date DESC
    """).to_pandas()

@st.cache_data(ttl=60)
def get_entity_accounts():
    return session.sql("SELECT * FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS ORDER BY entity_name").to_pandas()

@st.cache_data(ttl=60)
def get_reallocations():
    return session.sql("""
        SELECT reallocation_id, reallocation_date, source_entity_id, source_entity_name,
               dest_entity_id, dest_entity_name, amount, motif, created_at
        FROM CONSUMPTION_DB.MONITORING.BUDGET_REALLOCATIONS 
        ORDER BY reallocation_date DESC, created_at DESC
    """).to_pandas()

def upsert_budget(entity_id, entity_name, budget_amount, start_date, end_date, notes):
    session.sql(f"""
        MERGE INTO CONSUMPTION_DB.MONITORING.ENTITY_BUDGETS AS target
        USING (SELECT '{entity_id}' AS entity_id) AS source
        ON target.entity_id = source.entity_id
        WHEN MATCHED THEN UPDATE SET 
            entity_name = '{entity_name}',
            budget_amount = {budget_amount}, 
            start_date = '{start_date}',
            end_date = '{end_date}',
            notes = '{notes}', 
            updated_at = CURRENT_TIMESTAMP()
        WHEN NOT MATCHED THEN INSERT (entity_id, entity_name, budget_amount, start_date, end_date, notes)
            VALUES ('{entity_id}', '{entity_name}', {budget_amount}, '{start_date}', '{end_date}', '{notes}')
    """).collect()
    st.cache_data.clear()

def delete_budget(entity_id):
    session.sql(f"DELETE FROM CONSUMPTION_DB.MONITORING.ENTITY_BUDGETS WHERE entity_id = '{entity_id}'").collect()
    st.cache_data.clear()

def insert_reallocation(reallocation_date, source_entity_id, source_entity_name, dest_entity_id, dest_entity_name, amount, motif):
    motif_escaped = motif.replace("'", "''")
    source_name_escaped = source_entity_name.replace("'", "''")
    dest_name_escaped = dest_entity_name.replace("'", "''")
    session.sql(f"""
        INSERT INTO CONSUMPTION_DB.MONITORING.BUDGET_REALLOCATIONS 
        (reallocation_date, source_entity_id, source_entity_name, dest_entity_id, dest_entity_name, amount, motif)
        VALUES ('{reallocation_date}', '{source_entity_id}', '{source_name_escaped}', '{dest_entity_id}', '{dest_name_escaped}', {amount}, '{motif_escaped}')
    """).collect()
    st.cache_data.clear()

def get_available_budget(entity_id):
    result = session.sql(f"""
        SELECT BUDGET_CREDITS 
        FROM CONSUMPTION_DB.MONITORING.V_BUDGET_VS_ACTUAL 
        WHERE ENTITY_ID = '{entity_id}'
    """).to_pandas()
    if result.empty:
        return 0
    return float(result.iloc[0]['BUDGET_CREDITS'])

try:
    df_entities = get_entities()
    df_budgets = get_budgets()
    df_org = get_org_consumption()
    df_consumption = get_all_consumption()
    df_entity_accounts = get_entity_accounts()
    
    df_reallocations = get_reallocations()
    
    tab_names = ["📊 Vue Org", "💰 Gestion Budgets", "🔄 Réallocations", "🏢 Entités", "📈 Suivi Hebdo"]
    
    def render_tab_buttons():
        if "current_tab" not in st.session_state:
            st.session_state.current_tab = 0
        cols = st.columns(len(tab_names))
        for i, (col, name) in enumerate(zip(cols, tab_names)):
            with col:
                btn_type = "primary" if st.session_state.current_tab == i else "secondary"
                if st.button(name, key=f"tab_btn_{i}", type=btn_type, use_container_width=True):
                    st.session_state.current_tab = i
                    st.rerun()
    
    render_tab_buttons()
    st.markdown("---")
    current_tab = st.session_state.current_tab
    
    if current_tab == 0:
        st.subheader("Vue consolidée de l'organisation")
        
        if not df_org.empty:
            latest = df_org.iloc[0]
            col1, col2, col3, col4 = st.columns(4)
            with col1:
                st.metric("Comptes actifs", f"{int(latest['ACTIVE_ACCOUNTS'])}")
            with col2:
                st.metric("Entités actives", f"{int(latest['ACTIVE_ENTITIES'])}")
            with col3:
                st.metric("Crédits totaux", f"{latest['TOTAL_CREDITS']:,.2f}")
            with col4:
                st.metric("Coût total", f"${latest['TOTAL_COST_USD']:,.2f}")
            
            df_org['MONTH_LABEL'] = pd.to_datetime(df_org['MONTH']).dt.strftime('%b %Y')
            df_org['TOTAL_CREDITS'] = pd.to_numeric(df_org['TOTAL_CREDITS'], errors='coerce').fillna(0)
            df_org_sorted = df_org.sort_values('MONTH')
            fig = go.Figure(go.Bar(
                x=df_org_sorted["MONTH_LABEL"].tolist(),
                y=df_org_sorted["TOTAL_CREDITS"].tolist(),
                marker_color=CAPFM_COLORS["vert_fonce"]
            ))
            fig.update_layout(title="Consommation des 6 derniers mois")
            st.plotly_chart(fig, use_container_width=True)
        
        if not df_consumption.empty:
            df_treemap = df_consumption.groupby("ENTITY_NAME").agg({"CREDITS": "sum"}).reset_index()
            df_treemap["CREDITS"] = pd.to_numeric(df_treemap["CREDITS"], errors='coerce').fillna(0)
            df_treemap = df_treemap.sort_values("CREDITS", ascending=True)
            df_treemap["CREDITS_LABEL"] = df_treemap["CREDITS"].apply(lambda x: f"{x:,.2f} crédits")
            
            fig2 = go.Figure(go.Bar(
                x=df_treemap["CREDITS"].tolist(),
                y=df_treemap["ENTITY_NAME"].tolist(),
                orientation='h',
                text=df_treemap["CREDITS_LABEL"].tolist(),
                textposition="outside",
                marker_color=CAPFM_COLORS["vert_fonce"]
            ))
            max_credits = df_treemap["CREDITS"].max()
            fig2.update_layout(
                title="Répartition par entité",
                showlegend=False, 
                yaxis_title="", 
                xaxis_title="Crédits",
                xaxis=dict(range=[0, max_credits * 1.3])
            )
            st.plotly_chart(fig2, use_container_width=True)
    
    elif current_tab == 1:
        st.subheader("Saisie et modification des budgets (dates libres)")
        st.caption("⚠️ Un seul budget actif par entité. Créer un nouveau budget écrase l'ancien et remet la consommation à zéro.")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.markdown("### ➕ Nouveau budget")
            with st.form("new_budget"):
                entity = st.selectbox("Entité", df_entities["ENTITY_NAME"].tolist())
                entity_row = df_entities[df_entities["ENTITY_NAME"] == entity]
                entity_id = entity_row["ENTITY_ID"].values[0] if not entity_row.empty else None
                
                col_d1, col_d2 = st.columns(2)
                with col_d1:
                    start_date = st.date_input("Date début", value=date.today().replace(month=1, day=1))
                with col_d2:
                    end_date = st.date_input("Date fin", value=date.today().replace(month=12, day=31))
                
                budget_amount = st.number_input("Budget (crédits)", min_value=0, value=10000, step=1000)
                notes = st.text_input("Notes", "")
                
                if st.form_submit_button("💾 Enregistrer", type="primary"):
                    if entity_id:
                        if end_date <= start_date:
                            st.error("La date de fin doit être postérieure à la date de début.")
                        else:
                            try:
                                upsert_budget(entity_id, entity, budget_amount, start_date, end_date, notes)
                                st.success(f"Budget créé/mis à jour pour {entity}")
                                st.rerun()
                            except Exception as e:
                                st.error(f"Erreur: {e}")
        
        with col2:
            st.markdown("### 📋 Budgets existants")
            if not df_budgets.empty:
                for _, row in df_budgets.iterrows():
                    duration = (row['END_DATE'] - row['START_DATE']).days + 1
                    with st.expander(f"**{row['ENTITY_ID']}** : {row['BUDGET_AMOUNT']:,.0f} cr ({row['START_DATE']} → {row['END_DATE']}, {duration}j)"):
                        col_a, col_b = st.columns([3, 1])
                        with col_a:
                            st.markdown(f"""
                            - **Entité**: {row['ENTITY_NAME']}
                            - **Période**: {row['START_DATE']} au {row['END_DATE']} ({duration} jours)
                            - **Budget**: {row['BUDGET_AMOUNT']:,.0f} crédits
                            - **Notes**: {row['NOTES'] or '-'}
                            """)
                        with col_b:
                            if st.button("🗑️ Supprimer", key=f"del_{row['ENTITY_ID']}"):
                                delete_budget(row['ENTITY_ID'])
                                st.warning("Budget supprimé!")
                                st.rerun()
            else:
                st.info("Aucun budget défini")
    
    elif current_tab == 2:
        st.subheader("Réallocations budgétaires entre entités")
        st.caption("⚠️ Les réallocations sont définitives et ne peuvent pas être modifiées ou annulées.")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.markdown("### ➕ Nouvelle réallocation")
            with st.form("new_reallocation"):
                entity_list = df_entities["ENTITY_ID"].tolist()
                entity_names = df_entities.set_index("ENTITY_ID")["ENTITY_NAME"].to_dict()
                
                source_entity = st.selectbox(
                    "Entité source (qui donne)", 
                    entity_list,
                    format_func=lambda x: f"{x} - {entity_names.get(x, x)}"
                )
                dest_entity = st.selectbox(
                    "Entité destination (qui reçoit)", 
                    entity_list,
                    format_func=lambda x: f"{x} - {entity_names.get(x, x)}"
                )
                
                realloc_date = st.date_input("Date de réallocation", value=date.today())
                amount = st.number_input("Montant (crédits)", min_value=1, value=1000, step=100)
                motif = st.text_area("Motif", placeholder="Ex: Transfert suite à demande email du 15/02")
                
                if st.form_submit_button("💾 Enregistrer la réallocation", type="primary"):
                    if source_entity == dest_entity:
                        st.error("L'entité source et destination doivent être différentes.")
                    elif amount <= 0:
                        st.error("Le montant doit être strictement positif.")
                    elif not motif.strip():
                        st.error("Le motif est obligatoire.")
                    else:
                        available_budget = get_available_budget(source_entity)
                        if amount > available_budget:
                            st.error(f"Budget insuffisant! L'entité {source_entity} n'a que {available_budget:,.0f} crédits disponibles.")
                        else:
                            try:
                                source_name = entity_names.get(source_entity, source_entity)
                                dest_name = entity_names.get(dest_entity, dest_entity)
                                insert_reallocation(realloc_date, source_entity, source_name, dest_entity, dest_name, amount, motif)
                                st.success(f"Réallocation de {amount:,.0f} crédits de {source_entity} vers {dest_entity} enregistrée!")
                                st.balloons()
                            except Exception as e:
                                st.error(f"Erreur: {e}")
        
        with col2:
            st.markdown("### 📋 Historique des réallocations")
            if not df_reallocations.empty:
                df_display = df_reallocations.copy()
                df_display['REALLOCATION_DATE'] = pd.to_datetime(df_display['REALLOCATION_DATE']).dt.strftime('%Y-%m-%d')
                df_display['AMOUNT'] = df_display['AMOUNT'].apply(lambda x: f"{x:,.0f}")
                df_display = df_display.rename(columns={
                    'REALLOCATION_DATE': 'Date',
                    'SOURCE_ENTITY_NAME': 'Source',
                    'DEST_ENTITY_NAME': 'Destination', 
                    'AMOUNT': 'Crédits',
                    'MOTIF': 'Motif'
                })
                st.dataframe(
                    df_display[['Date', 'Source', 'Destination', 'Crédits', 'Motif']],
                    use_container_width=True,
                    hide_index=True
                )
                
                total_realloc = df_reallocations['AMOUNT'].sum()
                st.info(f"📊 Total réalloué: {total_realloc:,.0f} crédits en {len(df_reallocations)} opérations")
            else:
                st.info("Aucune réallocation enregistrée")
    
    elif current_tab == 3:
        st.subheader("Mapping Entités ↔ Comptes Snowflake")
        
        st.dataframe(
            df_entity_accounts[["ENTITY_ID", "ENTITY_NAME", "ACCOUNT_LOCATOR", "ACCOUNT_NAME", "REGION", "IS_ACTIVE"]],
            use_container_width=True
        )
        
        st.markdown("---")
        st.markdown("### ➕ Ajouter un mapping")
        with st.form("new_entity_mapping"):
            col1, col2 = st.columns(2)
            with col1:
                new_entity_id = st.text_input("Entity ID (code)", placeholder="AGOS")
                new_entity_name = st.text_input("Nom entité", placeholder="AGOS Italy")
            with col2:
                new_account_locator = st.text_input("Account Locator", placeholder="ZIC37939")
                new_account_name = st.text_input("Account Name", placeholder="ACC_TEAM_EU")
            
            if st.form_submit_button("Ajouter"):
                if new_entity_id and new_account_locator:
                    try:
                        session.sql(f"""
                            INSERT INTO CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS 
                            (entity_id, entity_name, account_locator, account_name, region)
                            VALUES ('{new_entity_id}', '{new_entity_name}', '{new_account_locator}', '{new_account_name}', CURRENT_REGION())
                        """).collect()
                        session.sql("""
                            CREATE OR REPLACE TABLE CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS_LOOKUP AS 
                            SELECT entity_id, account_locator FROM CONSUMPTION_DB.MONITORING.ENTITY_ACCOUNTS
                        """).collect()
                        st.success("Mapping ajouté!")
                        st.cache_data.clear()
                        st.rerun()
                    except Exception as e:
                        st.error(f"Erreur: {e}")
    
    elif current_tab == 4:
        st.subheader("Suivi hebdomadaire cumulé (26 dernières semaines)")
        
        def weekly_view():
            entity_options = ["Toutes"] + df_entities["ENTITY_NAME"].tolist()
            selected_entity = st.selectbox("Filtrer par entité", entity_options, key="weekly_entity")
            
            if not df_consumption.empty:
                df_weekly = df_consumption.copy()
                budget_amount = None
                
                if selected_entity != "Toutes":
                    df_weekly = df_weekly[df_weekly["ENTITY_NAME"] == selected_entity]
                    entity_budget = df_budgets[df_budgets["ENTITY_NAME"] == selected_entity]
                    if not entity_budget.empty:
                        budget_amount = entity_budget.iloc[0]["BUDGET_AMOUNT"]
                
                cutoff_date = (datetime.now() - pd.Timedelta(weeks=26)).date()
                df_weekly = df_weekly[pd.to_datetime(df_weekly["USAGE_DATE"]).dt.date >= cutoff_date]
                
                df_weekly['USAGE_DATE'] = pd.to_datetime(df_weekly['USAGE_DATE'])
                df_weekly['WEEK_START'] = df_weekly['USAGE_DATE'].dt.to_period('W-MON').dt.start_time
                
                weekly_agg = df_weekly.groupby('WEEK_START').agg({'CREDITS': 'sum'}).reset_index()
                weekly_agg = weekly_agg.sort_values('WEEK_START')
                weekly_agg['CUMUL_CREDITS'] = weekly_agg['CREDITS'].cumsum()
                weekly_agg['WEEK_LABEL'] = weekly_agg['WEEK_START'].dt.strftime('S%V %Y')
                
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Total 26 semaines", f"{weekly_agg['CREDITS'].sum():,.2f} cr")
                col2.metric("Moyenne/semaine", f"{weekly_agg['CREDITS'].mean():,.2f} cr")
                col3.metric("Cumul actuel", f"{weekly_agg['CUMUL_CREDITS'].iloc[-1]:,.2f} cr" if not weekly_agg.empty else "0 cr")
                col4.metric("Budget", f"{budget_amount:,.0f} cr" if budget_amount else "Non défini")
                
                fig = go.Figure()
                
                max_cumul = weekly_agg['CUMUL_CREDITS'].max() if not weekly_agg.empty else 1
                y_max = max_cumul * 1.2
                
                fig.add_trace(go.Bar(
                    x=weekly_agg['WEEK_LABEL'].tolist(),
                    y=weekly_agg['CREDITS'].tolist(),
                    name='Crédits/semaine',
                    marker_color=CAPFM_COLORS["vert_clair"]
                ))
                fig.add_trace(go.Scatter(
                    x=weekly_agg['WEEK_LABEL'].tolist(),
                    y=weekly_agg['CUMUL_CREDITS'].tolist(),
                    name='Cumul crédits',
                    mode='lines+markers',
                    marker=dict(size=10),
                    line=dict(color=CAPFM_COLORS["vert_fonce"], width=3)
                ))
                
                fig.update_layout(
                    title="Consommation hebdomadaire + Cumul (26 semaines)",
                    yaxis=dict(title='Crédits', range=[0, y_max]),
                    legend=dict(orientation='h', yanchor='bottom', y=1.02),
                    xaxis_tickangle=-45
                )
                st.plotly_chart(fig, use_container_width=True)
                
                with st.expander("📋 Données détaillées"):
                    st.dataframe(weekly_agg[['WEEK_LABEL', 'CREDITS', 'CUMUL_CREDITS']], use_container_width=True)
        
        weekly_view()

except Exception as e:
    st.error(f"Erreur: {str(e)}")
    st.info("Vérifiez que vous êtes connecté avec le rôle BUDGET_ADMIN ou ACCOUNTADMIN.")

st.markdown("---")
st.markdown(f"""
<div style="text-align: center; color: {CAPFM_COLORS['vert_fonce']};">
    <small>CAPFM Admin Console V3 • Producer Account • Contact: patrick.fromont@snowflake.com</small>
</div>
""", unsafe_allow_html=True)
