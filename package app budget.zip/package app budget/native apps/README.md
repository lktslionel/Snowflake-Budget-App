# CAPFM Consumption Monitor V2

Application Native Snowflake pour le suivi de consommation multi-comptes.

## Fonctionnalités V2

- **Budgets flexibles** : Définissez des budgets avec dates de début et fin personnalisées (pas uniquement calendaires)
- **Vue Hebdomadaire** : Consommation par semaine ISO sur les 6 derniers mois, avec cumul
- **Vue Mensuelle** : Consommation mensuelle avec comparaison au budget linéaire attendu
- **Split par compte** : Pour les entités multi-comptes, visualisez la répartition par compte Snowflake
- **Axe temps continu** : Les périodes sans consommation affichent 0 (pas de trou dans les graphiques)

## Utilisation

1. Ouvrez l'application depuis Snowsight
2. Sélectionnez l'onglet souhaité (Hebdo, Mensuel, Budget)
3. Les données sont automatiquement filtrées selon votre entité

## Contact

Pour toute question, contactez l'administrateur CAPFM.
