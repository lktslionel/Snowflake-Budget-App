import streamlit as st
import pandas as pd
from snowflake.snowpark.context import get_active_session
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, timedelta

st.set_page_config(page_title="CAPFM - Consumption Monitor", page_icon="📊", layout="wide")

CAPFM_COLORS = {
    "vert_fonce": "#006A4E",
    "vert_clair": "#78BE20",
    "blanc": "#FFFFFF",
    "gris": "#F5F5F5"
}

st.markdown(f"""
<style>
    .main-header {{
        background: linear-gradient(90deg, {CAPFM_COLORS["vert_fonce"]} 0%, {CAPFM_COLORS["vert_clair"]} 100%);
        padding: 20px; border-radius: 10px; margin-bottom: 20px;
    }}
    .main-header h1 {{ color: {CAPFM_COLORS["blanc"]}; margin: 0; font-size: 28px; }}
</style>
<div class="main-header"><h1>📊 CAPFM - Suivi Consommation</h1></div>
""", unsafe_allow_html=True)

session = get_active_session()

@st.cache_data(ttl=300)
def load_weekly_data():
    return session.sql("SELECT * FROM CODE_SCHEMA.V_WEEKLY_CONSUMPTION ORDER BY WEEK_START").to_pandas()

@st.cache_data(ttl=300)
def load_monthly_data():
    return session.sql("SELECT * FROM CODE_SCHEMA.V_MONTHLY_CONSUMPTION ORDER BY MONTH_START").to_pandas()

@st.cache_data(ttl=300)
def load_budget_data():
    return session.sql("SELECT * FROM CODE_SCHEMA.V_BUDGET_VS_ACTUAL").to_pandas()

@st.cache_data(ttl=300)
def load_monthly_cumulative():
    return session.sql("SELECT * FROM CODE_SCHEMA.V_MONTHLY_CUMULATIVE ORDER BY MONTH_START").to_pandas()

@st.cache_data(ttl=60)
def load_reallocations():
    return session.sql("SELECT * FROM CODE_SCHEMA.V_BUDGET_REALLOCATIONS ORDER BY REALLOCATION_DATE DESC").to_pandas()

try:
    weekly_df = load_weekly_data()
    monthly_df = load_monthly_data()
    budget_df = load_budget_data()
    cumul_df = load_monthly_cumulative()
    realloc_df = load_reallocations()
    
    if weekly_df.empty and monthly_df.empty:
        st.warning("Aucune donnée de consommation disponible pour votre entité.")
        st.stop()

    entity_name = weekly_df['ENTITY_NAME'].iloc[0] if not weekly_df.empty else monthly_df['ENTITY_NAME'].iloc[0]
    st.info(f"📍 **Entité**: {entity_name}")
    
    has_multiple_accounts = False
    if not weekly_df.empty:
        has_multiple_accounts = weekly_df['ACCOUNT_LOCATOR'].nunique() > 1
    
    tab1, tab2, tab3, tab4 = st.tabs(["📊 Hebdomadaire", "📈 Mensuel + Budget", "💰 Statut Budget", "🔄 Réallocations"])
    
    with tab1:
        st.subheader("Consommation Hebdomadaire")
        
        if not weekly_df.empty:
            weekly_agg = weekly_df.groupby('WEEK_START').agg({
                'CREDITS_USED': 'sum',
                'COST_USD': 'sum'
            }).reset_index()
            weekly_agg['CUMUL_CREDITS'] = weekly_agg['CREDITS_USED'].cumsum()
            weekly_agg['WEEK_LABEL'] = pd.to_datetime(weekly_agg['WEEK_START']).dt.strftime('S%V %Y')
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Total 6 mois", f"{weekly_agg['CREDITS_USED'].sum():,.2f} cr")
            col2.metric("Moyenne/Semaine", f"{weekly_agg['CREDITS_USED'].mean():,.2f} cr")
            col3.metric("Coût total", f"${weekly_agg['COST_USD'].sum():,.2f}")
            
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=weekly_agg['WEEK_LABEL'],
                y=weekly_agg['CREDITS_USED'],
                name='Crédits/semaine',
                marker_color=CAPFM_COLORS["vert_clair"]
            ))
            fig.add_trace(go.Scatter(
                x=weekly_agg['WEEK_LABEL'],
                y=weekly_agg['CUMUL_CREDITS'],
                name='Cumul crédits',
                line=dict(color=CAPFM_COLORS["vert_fonce"], width=3),
                yaxis='y2'
            ))
            fig.update_layout(
                title="Consommation par semaine (ISO) + Cumul",
                yaxis=dict(title='Crédits/semaine'),
                yaxis2=dict(title='Cumul crédits', overlaying='y', side='right'),
                legend=dict(orientation='h', yanchor='bottom', y=1.02)
            )
            st.plotly_chart(fig, use_container_width=True)
            
            if has_multiple_accounts:
                st.markdown("### Répartition par compte")
                weekly_by_account = weekly_df.groupby(['WEEK_START', 'ACCOUNT_NAME']).agg({
                    'CREDITS_USED': 'sum'
                }).reset_index()
                weekly_by_account['WEEK_LABEL'] = pd.to_datetime(weekly_by_account['WEEK_START']).dt.strftime('S%V %Y')
                
                fig_split = px.bar(
                    weekly_by_account,
                    x='WEEK_LABEL',
                    y='CREDITS_USED',
                    color='ACCOUNT_NAME',
                    title="Consommation par compte",
                    color_discrete_sequence=[CAPFM_COLORS["vert_fonce"], CAPFM_COLORS["vert_clair"], "#004d38", "#5cb85c"]
                )
                st.plotly_chart(fig_split, use_container_width=True)
            
            with st.expander("📋 Données détaillées"):
                st.dataframe(weekly_df, use_container_width=True)
    
    with tab2:
        st.subheader("Consommation Mensuelle vs Budget")
        
        if not cumul_df.empty:
            cumul_entity = cumul_df.groupby('MONTH_START').agg({
                'MONTHLY_CREDITS': 'sum',
                'CUMUL_CREDITS': 'max',
                'CUMUL_BUDGET_EXPECTED': 'max',
                'BUDGET_AMOUNT': 'max'
            }).reset_index()
            cumul_entity['MONTH_LABEL'] = pd.to_datetime(cumul_entity['MONTH_START']).dt.strftime('%b %Y')
            
            latest_budget = budget_df.iloc[0] if not budget_df.empty else None
            
            if latest_budget is not None:
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Budget Total", f"{latest_budget['BUDGET_CREDITS']:,.0f} cr")
                col2.metric("Consommé", f"{latest_budget['ACTUAL_CREDITS']:,.2f} cr")
                col3.metric("% Utilisé", f"{latest_budget['BUDGET_CONSUMPTION_PCT']:.1f}%")
                col4.metric("Restant", f"{latest_budget['REMAINING_CREDITS']:,.2f} cr")
                
                st.progress(min(latest_budget['BUDGET_CONSUMPTION_PCT']/100, 1.0))
            
            fig = go.Figure()
            fig.add_trace(go.Bar(
                x=cumul_entity['MONTH_LABEL'],
                y=cumul_entity['CUMUL_CREDITS'],
                name='Cumul consommation',
                marker_color=CAPFM_COLORS["vert_clair"]
            ))
            fig.add_trace(go.Scatter(
                x=cumul_entity['MONTH_LABEL'],
                y=cumul_entity['CUMUL_BUDGET_EXPECTED'],
                name='Budget linéaire attendu',
                line=dict(color=CAPFM_COLORS["vert_fonce"], width=3, dash='dash'),
                yaxis='y2'
            ))
            budget_max = cumul_entity['BUDGET_AMOUNT'].max()
            if budget_max > 0:
                fig.add_trace(go.Scatter(
                    x=[cumul_entity['MONTH_LABEL'].iloc[0], cumul_entity['MONTH_LABEL'].iloc[-1]],
                    y=[budget_max, budget_max],
                    name='Budget Total',
                    line=dict(color='red', width=2, dash='dot'),
                    yaxis='y2'
                ))
            fig.update_layout(
                title="Cumul Consommation vs Budget Linéaire",
                yaxis=dict(title='Consommation (crédits)', side='left'),
                yaxis2=dict(title='Budget (crédits)', side='right', overlaying='y'),
                legend=dict(orientation='h', yanchor='bottom', y=1.02)
            )
            st.plotly_chart(fig, use_container_width=True)
            
            if has_multiple_accounts:
                st.markdown("### Répartition mensuelle par compte")
                monthly_by_account = monthly_df.groupby(['MONTH_START', 'ACCOUNT_NAME']).agg({
                    'CREDITS_USED': 'sum'
                }).reset_index()
                monthly_by_account['MONTH_LABEL'] = pd.to_datetime(monthly_by_account['MONTH_START']).dt.strftime('%b %Y')
                
                fig_split = px.bar(
                    monthly_by_account,
                    x='MONTH_LABEL',
                    y='CREDITS_USED',
                    color='ACCOUNT_NAME',
                    title="Consommation mensuelle par compte",
                    color_discrete_sequence=[CAPFM_COLORS["vert_fonce"], CAPFM_COLORS["vert_clair"], "#004d38", "#5cb85c"]
                )
                st.plotly_chart(fig_split, use_container_width=True)
            
            with st.expander("📋 Données détaillées"):
                st.dataframe(monthly_df, use_container_width=True)
    
    with tab3:
        st.subheader("Statut du Budget")
        
        if not budget_df.empty:
            b = budget_df.iloc[0]
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown(f"""
                **Période du budget:**  
                📅 Du **{b['START_DATE']}** au **{b['END_DATE']}**  
                ⏱️ **{b['ELAPSED_DAYS']}** jours écoulés sur **{b['BUDGET_DAYS']}** jours
                """)
            with col2:
                status = b['BUDGET_STATUS']
                status_colors = {
                    'UNDER_BUDGET': ('🟢', 'success'),
                    'ON_TRACK': ('🟡', 'info'),
                    'WARNING': ('🟠', 'warning'),
                    'OVER_BUDGET': ('🔴', 'error')
                }
                icon, msg_type = status_colors.get(status, ('⚪', 'info'))
                getattr(st, msg_type)(f"{icon} Statut: **{status}**")
            
            st.markdown("---")
            
            if 'BUDGET_INITIAL' in b and 'BUDGET_RECU' in b and 'BUDGET_DONNE' in b:
                col1, col2, col3, col4 = st.columns(4)
                col1.metric("Budget Initial", f"{b['BUDGET_INITIAL']:,.0f} cr")
                col2.metric("Reçu", f"+{b['BUDGET_RECU']:,.0f} cr")
                col3.metric("Donné", f"-{b['BUDGET_DONNE']:,.0f} cr")
                col4.metric("Budget Effectif", f"{b['BUDGET_CREDITS']:,.0f} cr")
            else:
                col1, col2, col3 = st.columns(3)
                col1.metric("Budget Total", f"{b['BUDGET_CREDITS']:,.0f} crédits")
                col2.metric("Attendu à ce jour", f"{b['EXPECTED_CREDITS_TO_DATE']:,.2f} crédits")
                col3.metric("Réel à ce jour", f"{b['ACTUAL_CREDITS']:,.2f} crédits")
            
            delta = b['ACTUAL_CREDITS'] - b['EXPECTED_CREDITS_TO_DATE']
            if delta > 0:
                st.warning(f"⚠️ Vous êtes **{delta:,.2f} crédits** au-dessus du rythme prévu.")
            else:
                st.success(f"✅ Vous êtes **{abs(delta):,.2f} crédits** en-dessous du rythme prévu.")
            
            st.markdown("### Équivalent en USD")
            col1, col2, col3 = st.columns(3)
            col1.metric("Budget USD", f"${b['BUDGET_AMOUNT_USD']:,.2f}")
            col2.metric("Consommé USD", f"${b['ACTUAL_COST_USD']:,.2f}")
            col3.metric("Restant USD", f"${b['REMAINING_AMOUNT_USD']:,.2f}")
        else:
            st.info("Aucun budget actif défini pour cette entité.")
            st.caption("Contactez votre administrateur CAPFM pour définir un budget.")
    
    with tab4:
        st.subheader("Réallocations de Budget")
        
        if not realloc_df.empty:
            donnees = realloc_df[realloc_df['SENS'] == 'DONNE'] if 'SENS' in realloc_df.columns else pd.DataFrame()
            recues = realloc_df[realloc_df['SENS'] == 'RECU'] if 'SENS' in realloc_df.columns else pd.DataFrame()
            
            col1, col2, col3 = st.columns(3)
            col1.metric("Total Donné", f"-{donnees['AMOUNT'].sum():,.0f} cr" if not donnees.empty else "0 cr")
            col2.metric("Total Reçu", f"+{recues['AMOUNT'].sum():,.0f} cr" if not recues.empty else "0 cr")
            col3.metric("Nb Réallocations", f"{len(realloc_df)}")
            
            st.markdown("### Historique")
            
            display_df = realloc_df[['REALLOCATION_DATE', 'SOURCE_ENTITY_NAME', 'DEST_ENTITY_NAME', 'AMOUNT', 'MOTIF', 'SENS']].copy()
            display_df['AMOUNT'] = display_df['AMOUNT'].apply(lambda x: f"{int(x)}")
            display_df.columns = ['Date', 'De', 'Vers', 'Montant (cr)', 'Motif', 'Type']
            
            st.dataframe(
                display_df.style.apply(
                    lambda x: ['background-color: #ffe6e6' if v == 'DONNE' else 'background-color: #e6ffe6' if v == 'RECU' else '' for v in x],
                    subset=['Type']
                ),
                use_container_width=True,
                hide_index=True
            )
        else:
            st.info("Aucune réallocation de budget enregistrée pour votre entité.")

except Exception as e:
    st.error(f"Erreur: {e}")
    st.info("Contactez l'administrateur CAPFM.")
